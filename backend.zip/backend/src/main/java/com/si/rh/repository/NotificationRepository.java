package com.si.rh.repository;

import com.si.rh.model.Notification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.*;

@Repository
public interface NotificationRepository extends JpaRepository<Notification, Integer> {
    List<Notification> findByUtilisateur_IdOrderByDateCreationDesc(Integer utilisateurId);

    Optional<Notification> findByIdAndUtilisateur_Id(Integer id, Integer utilisateurId);
}

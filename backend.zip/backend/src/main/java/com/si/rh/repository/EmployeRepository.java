//Brandon
package com.si.rh.repository;

import com.si.rh.model.Employe;
import com.si.rh.model.enums.StatutEmploye;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface EmployeRepository extends JpaRepository<Employe, Integer> {

    Optional<Employe> findByMatricule(String matricule);

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("SELECT e FROM Employe e WHERE e.id = :id")
    Optional<Employe> findByIdForUpdate(@Param("id") Integer id);

    Optional<Employe> findByMatriculeAndEmailAndNumeroCinAndStatut(
            String matricule,
            String email,
            String numeroCin,
            StatutEmploye statut);

    List<Employe> findByStatutOrderByNomAscPrenomAsc(StatutEmploye statut);

    List<Employe> findByDepartement_IdAndStatutOrderByNomAscPrenomAsc(
            Integer departementId,
            StatutEmploye statut);

    @Query("SELECT e FROM Employe e WHERE e.candidature.id = :idCandidature")
    Optional<Employe> findByIdCandidature(@Param("idCandidature") Integer idCandidature);

    @Query("SELECT COUNT(e) > 0 FROM Employe e WHERE e.candidature.id = :idCandidature")
    boolean existsByIdCandidature(@Param("idCandidature") Integer idCandidature);

    List<Employe> findByDepartement_Id(Integer departementId);

    long countByDepartement_IdAndStatut(Integer departementId, StatutEmploye statut);
}

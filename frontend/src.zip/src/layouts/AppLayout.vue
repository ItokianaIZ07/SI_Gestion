<script setup>
import { useAuthStore } from "@/stores/authStore";
import "../assets/theme.css";
import { getSidebarLinks } from "@/config/sidebar";
import { useRouter } from "vue-router";

const authStore = useAuthStore();
const router = useRouter();

const role = authStore.user.role; // ty rôle alaina avy any @ serveur atokana anaty config mints à partir ny store
const sidebar = getSidebarLinks(role);
// sidebar.unshift({label: "Dashboard", to: "/si/app"});

const logout = async () => {
  const response = await authStore.logout();
  if(response.success){
    router.replace('/');
  }
}
</script>

<template>
  <div class="app-layout">
    <aside>
      <nav>
        <RouterLink to="/si/app">Dashboard</RouterLink>
        <RouterLink v-for="link in sidebar" :to="link.to" :key="link.to">
          {{ link.label }}</RouterLink
        >
        <button class="btn-logout" @click="logout()">Se Deconnecter</button>
      </nav>
    </aside>

    <main>
      <!-- eto no injecter ny vue rehetra momban'le app sauf ny view an'ny candidat -->
      <RouterView />
    </main>
  </div>
</template>

<style scoped>
/* ==============================
   Layout général
============================== */

.app-layout {
  min-height: 100vh;
  background-color: var(--color-background);
}

/* ==============================
   Sidebar
============================== */

aside {
  position: fixed;
  top: 0;
  left: 0;
  bottom: 0;

  display: flex;
  flex-direction: column;

  width: 250px;
  height: 100vh;
  box-sizing: border-box;

  background-color: var(--color-card);
  border-right: 1px solid #e5e7eb;

  padding: 24px 16px;
  overflow-y: auto;
  z-index: 100;
}

/* Navigation */

nav {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

/* Liens */

nav a {
  display: flex;
  align-items: center;

  padding: 12px 14px;
  border-radius: 8px;

  color: #4b5563;
  text-decoration: none;
  font-size: 14px;
  font-weight: 500;

  transition:
    background-color 0.2s ease,
    color 0.2s ease;
}

/* Survol */

nav a:hover {
  background-color: var(--color-background);
  color: var(--color-primary);
}

/* Route active */

nav a.router-link-exact-active {
  background-color: #e8f3e9;
  color: var(--color-primary);
  font-weight: 600;
}

/* ==============================
   Contenu principal
============================== */

main {
  margin-left: 250px;
  margin-top: -72px;
  min-width: 0;
  min-height: 100vh;
  box-sizing: border-box;

  padding: 32px;
  background-color: var(--color-background);
}

.btn-logout {
  cursor: pointer;
  height: 8vh;
  border-radius: 4px;
  outline: none;
  border: 1px solid #d4d4d4;
  color: var(--color-primary);
  transition: all ease-in 150ms;
  bottom: 0;
}

.btn-logout:hover{
  box-shadow: 0 1px 1px 1px rgba(128, 128, 128, 0.55);
}

.btn-logout:active{
  box-shadow: none;
  bottom: 0;
}

/* ==============================
   Responsive : tablette et mobile
============================== */

@media (max-width: 768px) {
  aside {
    width: 200px;
    padding: 20px 12px;
  }

  main {
    margin-left: 200px;
    padding: 20px;
  }
}

@media (max-width: 480px) {
  aside {
    width: 72px;
    padding: 20px 8px;
  }

  nav a {
    justify-content: center;
    padding: 12px 4px;
    font-size: 0;
  }

  main {
    margin-left: 72px;
    padding: 16px;
  }
}
</style>
